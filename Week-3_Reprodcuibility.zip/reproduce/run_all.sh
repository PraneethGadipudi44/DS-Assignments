#!/usr/bin/env bash
set -euo pipefail
cd repo

# BASELINE — Gemini, difficulty=auto
python main.py \
  --model gemini-pro \
  --dataset medqa \
  --difficulty auto \
  > ../logs/medqa_gemini_baseline_auto.log 2>&1

# VARIATION — Gemini, difficulty=easy (one parameter changed)
python main.py \
  --model gemini-pro \
  --dataset medqa \
  --difficulty easy \
  > ../logs/medqa_gemini_variation_easy.log 2>&1