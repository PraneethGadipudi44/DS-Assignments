

## Results

Source logs:
- `logs/medqa_gemini_baseline_auto.log`
- `logs/medqa_gemini_variation_easy.log`

Parsed summary:

| Run | # Items | Difficulties Observed |
|---|---:|---|
| Baseline (Gemini, difficulty=auto) | 5 | auto, auto, auto, auto, auto |
| Variation (Gemini, difficulty=easy) | 5 | easy, easy, easy, easy, easy |

Notes:
- Both runs completed without errors.
- Controlled change was **one parameter** only: `--difficulty` (`auto` → `easy`).
- This small MedQA subset (5 items) is for the lab’s smoke test. For a full evaluation, substitute the official test split at the same path and re-run the same commands.
